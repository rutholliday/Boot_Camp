## Kid in a Candy Store

### Instructions

* Create a loop that prints all of the candies in the store to the terminal with their index stored in brackets beside them.

  * For example: `"[0] Snickers"`

  * Create a loop that runs for a number of times as determined by the variable `allowance`.

    * For example: If allowance is equal to five, the loop should run five times.

  * Each time this second loop runs, take in a user's input - preferably a number - and then add the candy with a matching index to the variable `candyCart`.

    * For example: If the user enters "0" as their input, "Snickers" should be added into the `candyCart` list.

  * Use another loop to print all of the candies selected to the terminal.

### Bonus

* Create a version of the same code which allows a user to select as much candy as they want up until they say they do not want any more.
